package com.obs.pn.ticketenrichi.logging

import org.slf4j.Logger
import org.slf4j.LoggerFactory
/**
 * A dummy class to be used in the logging in case we are not able to register current
 * Scala Object with the Logger instance.
 */
class CommonLogger {

}